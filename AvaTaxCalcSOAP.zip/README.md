C# sample of the SOAP API and Avatax Adapter demonstrating: ValidateAddress, GetTax, PostTax, CancelTax, and GetTaxHistory.

To run this sample, you will need to enter an account number, license key, and company code in Program.cs